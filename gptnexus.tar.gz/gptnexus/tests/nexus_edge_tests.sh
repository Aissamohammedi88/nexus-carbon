#!/usr/bin/env bash
# GPTNexus edge test bench — 13 tests (N01-N13)
# DGK x GLM — protocole ULTRA. Preuve d'exécution pour chaque capacité.
set -uo pipefail

NX_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PATH="$HOME/.cargo/bin:$PATH"
SCAN_BIN="$NX_HOME/scanner/target/release/nexus_scan"
FIX="$NX_HOME/fixtures"
CORE="$NX_HOME/nexus_core.py"

PASS=0; FAIL=0; FAILED_TESTS=()

c_red()   { printf '\033[31m%s\033[0m' "$*"; }
c_green() { printf '\033[32m%s\033[0m' "$*"; }
c_yellow(){ printf '\033[33m%s\033[0m' "$*"; }

t() {
    local id="$1"; shift
    local desc="$1"; shift
    if "$@" >/tmp/nx_test_out 2>&1; then
        printf "  [$(c_green PASS)] %s  %s\n" "$id" "$desc"
        PASS=$((PASS+1))
    else
        printf "  [$(c_red   FAIL)] %s  %s\n" "$id" "$desc"
        sed 's/^/        | /' /tmp/nx_test_out | tail -8
        FAIL=$((FAIL+1))
        FAILED_TESTS+=("$id")
    fi
}

# ---- setup ---------------------------------------------------------------
if [[ ! -x "$SCAN_BIN" ]]; then
    ( cd "$NX_HOME/scanner" && cargo build --release ) >/tmp/nx_build.log 2>&1 || {
        cat /tmp/nx_build.log
        echo "FATAL: cargo build failed in setup" >&2
        exit 1
    }
fi

# sandbox frais pour les tests qui patchent (les fixtures restent vierges)
SB="/tmp/nx_sandbox_$$"
mkdir -p "$SB"
cp "$FIX"/vuln_eval.py "$FIX"/vuln_sql.py "$FIX"/vuln_import.py "$FIX"/safe_code.py "$SB/"
cleanup() { rm -rf "$SB" /tmp/nx_test_out /tmp/nx_build.log; }
trap cleanup EXIT

echo "$(c_yellow "GPTNexus edge bench — 13 tests (protocole ULTRA)")"
echo ""

# N01 — scanner compilé et versionne
t N01 "nexus_scan compilé, --version exit 0" \
    "$SCAN_BIN" --version

# N02 — Finding : eval détecté
t N02 "scanner détecte eval dans vuln_eval.py (R001)" \
    python3 -c "
import json, subprocess, sys
r = json.loads(subprocess.run([sys.argv[1], sys.argv[2]], capture_output=True, text=True).stdout)
assert any(f['rule'] == 'eval' for f in r['findings']), r
print('ok:', [f['rule'] for f in r['findings']])
" "$SCAN_BIN" "$FIX/vuln_eval.py"

# N03 — Finding : SQL concat détecté
t N03 "scanner détecte sql_concat dans vuln_sql.py (R004)" \
    python3 -c "
import json, subprocess, sys
r = json.loads(subprocess.run([sys.argv[1], sys.argv[2]], capture_output=True, text=True).stdout)
assert any(f['rule'] == 'sql_concat' for f in r['findings']), r
print('ok:', [f['rule'] for f in r['findings']])
" "$SCAN_BIN" "$FIX/vuln_sql.py"

# N04 — Finding : __import__ détecté
t N04 "scanner détecte dyn_import dans vuln_import.py (R003)" \
    python3 -c "
import json, subprocess, sys
r = json.loads(subprocess.run([sys.argv[1], sys.argv[2]], capture_output=True, text=True).stdout)
assert any(f['rule'] == 'dyn_import' for f in r['findings']), r
print('ok:', [f['rule'] for f in r['findings']])
" "$SCAN_BIN" "$FIX/vuln_import.py"

# N05 — anti-faux-positif : le code sain doit rester à 0
t N05 "scanner silencieux sur safe_code.py (0 détection)" \
    python3 -c "
import json, subprocess, sys
r = json.loads(subprocess.run([sys.argv[1], sys.argv[2]], capture_output=True, text=True).stdout)
assert r['count'] == 0, f'faux positif ! {r}'
print('ok: 0 findings sur code sain')
" "$SCAN_BIN" "$FIX/safe_code.py"

# N06 — ExploitGym : eval CONFIRMÉ par sonde contrôlée
t N06 "sonde eval CONFIRME l'exécution arbitraire (pid retourné)" \
    python3 "$CORE" exploit "$SB/vuln_eval.py" eval --json

# N07 — ExploitGym : injection SQL CONFIRMÉE
t N07 "sonde sql CONFIRME l'injection (1 OR 1=1 dans la requête)" \
    python3 "$CORE" exploit "$SB/vuln_sql.py" sql_concat --json

# N08 — Patching : eval patché + re-scan propre
t N08 "patch eval RÉUSSI + re-scan 0 détection" \
    bash -c '
        python3 "$0" patch "$1" eval --json
        "$2" "$1" | python3 -c "import json,sys; r=json.load(sys.stdin); assert not any(f[\"rule\"]==\"eval\" for f in r[\"findings\"]), r; print(\"rescan ok\")"
    ' "$CORE" "$SB/vuln_eval.py" "$SCAN_BIN"

# N09 — Long-horizon : le registre exige une impasse traversée AVANT succès
# (ULTRA: L — la persistance n'est pas une promesse, c'est une donnée lue)
t N09 "mission.json : >= 1 dead_end ET final == success (persistance prouvée)" \
    python3 -c "
import json
m = json.load(open('$SB/.nexus/mission.json'))
assert m['dead_ends'] >= 1, f'aucune impasse enregistrée : {m[\"dead_ends\"]}'
assert m['final'] == 'success', f'final={m[\"final\"]}'
print(f\"ok: {m['dead_ends']} impasse(s) traversée(s) avant succès — persistance prouvée\")
"

# N10 — sécurité : l'exploit est BLOQUÉ après patch
t N10 "sonde eval BLOQUÉE sur le fichier patché" \
    python3 "$CORE" exploit "$SB/vuln_eval.py" eval --json

# N11 — le patch préserve l'usage légitime (pas de patch qui casse tout)
# [harness fix] bash -c: le 1er arg positionnel est $0 — il faut un "_" placeholder
# avant les vrais args, sinon $1 est vide (bug attrapé au 1er passage).
t N11 "fichier patché compile ET '1+1' -> 2 (usage légitime préservé)" \
    bash -c '
        python3 -m py_compile "$1"
        out=$(python3 "$1" "1+1")
        [ "$out" = "2" ] && echo "legit ok: 1+1 -> $out"
    ' _ "$SB/vuln_eval.py"

# N12 — cerveau GLM branché en vrai (famille glm [ai-brain])
t N12 "GLM répond via z-ai (avis [glm-advisory] non vide)" \
    bash -c '
        out=$(python3 "$0" ask "Réponds en un seul mot: OK")
        echo "$out" | grep -q "\[glm-advisory\]"
        lines=$(echo "$out" | grep "\[glm-advisory\]" | sed "s/\[glm-advisory\] //" | tr -d "[:space:]")
        [ -n "$lines" ] && echo "glm advisory ok"
    ' "$CORE"

# N13 — autonomie : sweep de bout en bout sur le sandbox
t N13 "sweep autonome : 3 findings -> 3 confirmés -> patchés -> rescan 0 -> final=success" \
    bash -c '
        # vuln_import doit aussi être patché ; on relance un sweep complet
        python3 "$0" sweep "$1" --json
    ' "$CORE" "$SB"

echo ""
echo "─────────────────────────────────────────"
echo "  passed: $(c_green $PASS)    failed: $(c_red $FAIL)    total: $((PASS+FAIL))"
if [[ $FAIL -gt 0 ]]; then
    echo "  failed tests: ${FAILED_TESTS[*]}"
    exit 1
fi
echo "  status: $(c_green "ALL GREEN — ULTRA SATISFIED")"
echo "─────────────────────────────────────────"
